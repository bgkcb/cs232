
const students = [
  { id: 'S001', name: 'Alice Smith', email: 'alice@example.com', hardskills: ['C++', 'Python'], softskills: ['Teamwork', 'Communication'], activities: ['Hackathon', 'Workshop'] },
  { id: 'S002', name: 'Bob Johnson', email: 'bob@example.com', hardskills: ['Java', 'SQL'], softskills: ['Leadership'], activities: ['Seminar'] },
  { id: 'S003', name: 'Charlie Lee', email: 'charlie@example.com', hardskills: ['HTML', 'CSS'], softskills: ['Creativity'], activities: ['Design Contest'] }
];

function showPage(pageId) {
  document.querySelectorAll('.page').forEach(page => {
    page.classList.remove('active');
  });
  document.getElementById(pageId).classList.add('active');

  if (pageId === 'students') renderStudentList();
}

function renderStudentList() {
  const list = document.getElementById('studentList');
  list.innerHTML = '';
  students.forEach(student => {
    const li = document.createElement('li');
    li.textContent = student.name;
    li.style.cursor = 'pointer';
    li.onclick = () => showStudentDetail(student);
    list.appendChild(li);
  });
}

function showStudentDetail(student) {
  const detail = document.getElementById('studentInfo');
  detail.innerHTML = `
    <p><strong>ID:</strong> ${student.id}</p>
    <p><strong>Name:</strong> ${student.name}</p>
    <p><strong>Email:</strong> ${student.email}</p>
    <p><strong>Activities:</strong> ${student.activities.join(', ')}</p>
    <p><strong>Hard Skills:</strong> ${student.hardskills.join(', ')}</p>
    <p><strong>Soft Skills:</strong> ${student.softskills.join(', ')}</p>
  `;
  showPage('studentDetail');
}
