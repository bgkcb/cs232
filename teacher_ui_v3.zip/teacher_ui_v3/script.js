
const studentData = {
    'Nutt': {
        hard: { 'Coding': 4, 'Design': 5, 'Data Analysis': 3 },
        soft: { 'Teamwork': 5, 'Communication': 4, 'Problem Solving': 3 }
    },
    'Pakorn': {
        hard: { 'Coding': 5, 'Cloud Computing': 4 },
        soft: { 'Critical Thinking': 4, 'Creativity': 5 }
    },
    'Mali': {
        hard: { 'Leadership': 3, 'Cybersecurity': 4 },
        soft: { 'Emotional Intelligence': 5, 'Teamwork': 3 }
    }
};

function viewStudent(name) {
    document.getElementById('student-name').textContent = name;
    const hard = studentData[name].hard || {};
    const soft = studentData[name].soft || {};
    renderSkills('hard-skills', hard);
    renderSkills('soft-skills', soft);
    document.getElementById('student-detail').style.display = 'block';
}

function renderSkills(id, skills) {
    const container = document.getElementById(id);
    container.innerHTML = '';
    for (let skill in skills) {
        const level = skills[skill];
        const percent = (level / 5) * 100;
        container.innerHTML += `
            <div>
                ${skill}
                <div class="bar-container">
                    <div class="bar" style="width:${percent}%">${level}</div>
                </div>
            </div>
        `;
    }
}
